<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style type="text/css">
    .wrapper {
      text-align: center;
    }

    .image--cover {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      margin: 20px;
      object-fit: cover;
      object-position: center right;
    }

    .profile-info {
      margin-top: 20px;
    }

    .profile-name {
      font-size: 1.5em;
      margin-bottom: 10px;
    }

    .view-button {
      padding: 10px 20px;
      font-size: 1em;
      background-color: #3498db;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>

        <div class="brand">
            <div class="container">
                <div class="section-header">
                    <h3>Our Brands</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec viverra at massa sit amet ultricies. Nullam consequat, mauris non interdum cursus
                    </p>
                </div>
                <div class="brand-slider">
                    <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                    <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                    <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                    <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                    <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                    <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                          <div class="brand-item">      <div class="wrapper">
        <img src="https://i.kinja-img.com/gawker-media/image/upload/gd8ljenaeahpn0wslmlz.jpg" class="image--cover">
        <div class="profile-info">
          <h2 class="profile-name">Profile 1</h2>
          <button class="view-button btn">View Profile</button>
        </div>
      </div></div>
                </div>
            </div>
        </div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

