    <div class="home-slider">
            <div class="main-slider">
                <div class="main-slider-item"><img src="img/slider-1.jpg" alt="Slider Image" /></div>
                <div class="main-slider-item"><img src="img/slider-2.jpg" alt="Slider Image" /></div>
                <div class="main-slider-item"><img src="img/slider-3.jpg" alt="Slider Image" /></div>
            </div>
        </div>