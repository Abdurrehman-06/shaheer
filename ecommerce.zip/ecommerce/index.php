<?php 
    include "includes/header.php";
 ?>
        <!-- Header End -->
        
        
        <!-- Main Slider Start -->
        <?php 
    include "includes/ads.php";
 ?>
        <!-- Main Slider End -->
    

        <?php 
    include "includes/featured_products.php";
 ?>
        
<?php 
    include "includes/top_seller.php";
 ?>



     <?php  
        include "includes/footer.php";
     ?>

        
        

